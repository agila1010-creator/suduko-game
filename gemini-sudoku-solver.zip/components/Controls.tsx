
import React from 'react';

interface ControlsProps {
  onSolve: () => void;
  onClear: () => void;
  onReset: () => void;
  isSolving: boolean;
  isSolved: boolean;
}

const Controls: React.FC<ControlsProps> = ({ onSolve, onClear, onReset, isSolving, isSolved }) => {
  return (
    <div className="flex flex-wrap items-center justify-center gap-4 w-full max-w-md">
      <button
        onClick={onSolve}
        disabled={isSolving || isSolved}
        className="flex-1 bg-sky-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-sky-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition-all duration-200 shadow-lg hover:shadow-sky-500/30 disabled:shadow-none"
      >
        {isSolving ? 'Working...' : isSolved ? 'Solved!' : 'Solve with AI'}
      </button>
      <button
        onClick={onClear}
        disabled={isSolving}
        className="flex-1 bg-slate-700 text-slate-300 font-bold py-3 px-6 rounded-lg hover:bg-slate-600 disabled:opacity-50 transition-colors duration-200"
      >
        Clear
      </button>
      <button
        onClick={onReset}
        disabled={isSolving}
        className="flex-1 bg-slate-700 text-slate-300 font-bold py-3 px-6 rounded-lg hover:bg-slate-600 disabled:opacity-50 transition-colors duration-200"
      >
        Reset Example
      </button>
    </div>
  );
};

export default Controls;
