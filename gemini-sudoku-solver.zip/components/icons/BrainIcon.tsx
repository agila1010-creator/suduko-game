
import React from 'react';

const BrainIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v0A2.5 2.5 0 0 1 9.5 7v0A2.5 2.5 0 0 1 7 9.5v0A2.5 2.5 0 0 1 9.5 12v0A2.5 2.5 0 0 1 7 14.5v0A2.5 2.5 0 0 1 9.5 17v0A2.5 2.5 0 0 1 7 19.5v0A2.5 2.5 0 0 1 9.5 22" />
    <path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v0A2.5 2.5 0 0 0 14.5 7v0A2.5 2.5 0 0 0 17 9.5v0A2.5 2.5 0 0 0 14.5 12v0A2.5 2.5 0 0 0 17 14.5v0A2.5 2.5 0 0 0 14.5 17v0A2.5 2.5 0 0 0 17 19.5v0A2.5 2.5 0 0 0 14.5 22" />
    <path d="M12 4.5a2.5 2.5 0 0 0-2.5-2.5" />
    <path d="M12 4.5a2.5 2.5 0 0 1 2.5-2.5" />
    <path d="M12 7a2.5 2.5 0 0 0-2.5-2.5" />
    <path d="M12 7a2.5 2.5 0 0 1 2.5-2.5" />
    <path d="M12 9.5a2.5 2.5 0 0 0-2.5-2.5" />
    <path d="M12 9.5a2.5 2.5 0 0 1 2.5-2.5" />
    <path d="M12 12a2.5 2.5 0 0 0-2.5-2.5" />
    <path d="M12 12a2.5 2.5 0 0 1 2.5-2.5" />
    <path d="M12 14.5a2.5 2.5 0 0 0-2.5-2.5" />
    <path d="M12 14.5a2.5 2.5 0 0 1 2.5-2.5" />
    <path d="M12 17a2.5 2.5 0 0 0-2.5-2.5" />
    <path d="M12 17a2.5 2.5 0 0 1 2.5-2.5" />
    <path d="M12 19.5a2.5 2.5 0 0 0-2.5-2.5" />
    <path d="M12 19.5a2.5 2.5 0 0 1 2.5-2.5" />
  </svg>
);

export default BrainIcon;
