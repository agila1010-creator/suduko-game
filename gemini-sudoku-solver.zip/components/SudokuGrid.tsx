
import React from 'react';
import type { Grid } from '../types';

interface SudokuGridProps {
  grid: Grid;
  onCellChange: (row: number, col: number, value: string) => void;
  isSolved: boolean;
  initialGrid: boolean[][];
}

const SudokuGrid: React.FC<SudokuGridProps> = ({ grid, onCellChange, isSolved, initialGrid }) => {
  const getCellClasses = (row: number, col: number) => {
    let classes = 'sudoku-input flex items-center justify-center text-2xl font-bold w-full h-full text-center bg-transparent focus:outline-none focus:ring-2 focus:ring-sky-400 focus:z-10 rounded-md transition-colors duration-300 ';

    // Cell value styles
    if (isSolved) {
        classes += initialGrid[row][col] ? 'text-slate-100' : 'text-sky-400 animate-fade-in';
    } else {
        classes += initialGrid[row][col] ? 'text-slate-300' : 'text-sky-400';
    }

    if (isSolved) {
        classes += ' cursor-default';
    } else {
        classes += ' hover:bg-slate-700';
    }

    return classes;
  };

  const getBorderClasses = (row: number, col: number) => {
    let classes = 'relative ';
    if ((col + 1) % 3 === 0 && col < 8) classes += 'border-r-4 border-r-slate-600 ';
    if ((row + 1) % 3 === 0 && row < 8) classes += 'border-b-4 border-b-slate-600 ';
    if (col % 3 === 0 && col > 0) classes += 'border-l-2 border-l-slate-700 ';
    else if (col > 0) classes += 'border-l border-l-slate-800 ';
    if (row % 3 === 0 && row > 0) classes += 'border-t-2 border-t-slate-700 ';
    else if (row > 0) classes += 'border-t border-t-slate-800 ';
    return classes;
  };

  return (
    <div className="grid grid-cols-9 w-full aspect-square bg-slate-800 rounded-xl p-2 shadow-2xl font-mono border border-slate-700">
      {grid.map((row, rowIndex) =>
        row.map((cell, colIndex) => (
          <div key={`${rowIndex}-${colIndex}`} className={`aspect-square ${getBorderClasses(rowIndex, colIndex)}`}>
            <input
              type="number"
              min="1"
              max="9"
              value={cell || ''}
              onChange={(e) => onCellChange(rowIndex, colIndex, e.target.value)}
              readOnly={isSolved || initialGrid[rowIndex][colIndex]}
              className={getCellClasses(rowIndex, colIndex)}
              aria-label={`Cell R${rowIndex + 1} C${colIndex + 1}`}
            />
          </div>
        ))
      )}
    </div>
  );
};

export default SudokuGrid;
