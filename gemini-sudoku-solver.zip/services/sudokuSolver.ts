
import type { Grid, CellValue } from '../types';

const getPossibleValues = (grid: Grid, row: number, col: number): CellValue[] => {
  const possibilities = new Set<CellValue>([1, 2, 3, 4, 5, 6, 7, 8, 9]);

  for (let i = 0; i < 9; i++) {
    possibilities.delete(grid[row][i]);
    possibilities.delete(grid[i][col]);
  }

  const startRow = Math.floor(row / 3) * 3;
  const startCol = Math.floor(col / 3) * 3;
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      possibilities.delete(grid[startRow + r][startCol + c]);
    }
  }

  return Array.from(possibilities).filter(p => p !== null) as CellValue[];
};

const findBestEmptyCell = (grid: Grid): [number, number] | null => {
  let bestCell: [number, number] | null = null;
  let minRemainingValues = 10;

  for (let r = 0; r < 9; r++) {
    for (let c = 0; c < 9; c++) {
      if (grid[r][c] === null) {
        const remainingValues = getPossibleValues(grid, r, c).length;
        if (remainingValues < minRemainingValues) {
          minRemainingValues = remainingValues;
          bestCell = [r, c];
          if (minRemainingValues === 1) {
            return bestCell; // Optimization: can't get better than 1
          }
        }
      }
    }
  }
  return bestCell;
};


export const solveSudoku = (grid: Grid): Grid | null => {
  const solve = (currentGrid: Grid): Grid | null => {
    const cell = findBestEmptyCell(currentGrid);

    if (!cell) {
      return currentGrid; // Solved, no empty cells left
    }

    const [row, col] = cell;
    const possibleValues = getPossibleValues(currentGrid, row, col);

    for (const num of possibleValues) {
      currentGrid[row][col] = num;
      const solution = solve(currentGrid);
      if (solution) {
        return solution;
      }
      currentGrid[row][col] = null; // Backtrack
    }

    return null; // No solution found from this path
  };

  const gridCopy = grid.map(row => [...row]);
  return solve(gridCopy);
};
