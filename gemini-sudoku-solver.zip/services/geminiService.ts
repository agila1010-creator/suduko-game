
import { GoogleGenAI } from "@google/genai";
import type { Grid } from '../types';

const formatGridForPrompt = (grid: Grid): string => {
  return grid.map(row => row.map(cell => cell === null ? '_' : cell).join(' ')).join('\n');
};

export const getSolutionExplanation = async (puzzle: Grid, solution: Grid): Promise<string> => {
  if (!process.env.API_KEY) {
    return "API Key is not configured. Cannot generate explanation.";
  }
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const puzzleString = formatGridForPrompt(puzzle);
  const solutionString = formatGridForPrompt(solution);

  const prompt = `
You are an expert Sudoku teacher. Your task is to explain how to solve a given Sudoku puzzle using human-like logic, not a brute-force computer algorithm.

Here is the initial puzzle:
${puzzleString}

Here is the final solution:
${solutionString}

Please provide a step-by-step walkthrough of the logical deductions required to solve this puzzle. Start with the easiest steps (like finding "naked singles") and progress from there.
- Use markdown for formatting, especially bolding cell coordinates (e.g., **R1C3**) and numbers.
- Explain the 'why' behind each number placement. For example: "In **R1C4**, the only possible number is **6** because the row, column, and 3x3 box already contain all other numbers."
- Keep the explanation clear, encouraging, and easy for a beginner to follow.
- Do not mention computer science terms like backtracking or recursion.
- Structure your response with a brief intro, a few key logical steps, and a concluding sentence.
`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error generating explanation from Gemini:", error);
    throw new Error("Failed to get explanation from Gemini API.");
  }
};
