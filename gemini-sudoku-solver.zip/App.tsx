
import React, { useState, useCallback, useMemo } from 'react';
import type { Grid, CellValue } from './types';
import { solveSudoku } from './services/sudokuSolver';
import { getSolutionExplanation } from './services/geminiService';
import SudokuGrid from './components/SudokuGrid';
import Controls from './components/Controls';
import BrainIcon from './components/icons/BrainIcon';
import SparklesIcon from './components/icons/SparklesIcon';

const EXAMPLE_PUZZLE: Grid = [
  [5, 3, null, null, 7, null, null, null, null],
  [6, null, null, 1, 9, 5, null, null, null],
  [null, 9, 8, null, null, null, null, 6, null],
  [8, null, null, null, 6, null, null, null, 3],
  [4, null, null, 8, null, 3, null, null, 1],
  [7, null, null, null, 2, null, null, null, 6],
  [null, 6, null, null, null, null, 2, 8, null],
  [null, null, null, 4, 1, 9, null, null, 5],
  [null, null, null, null, 8, null, null, 7, 9],
];

const EMPTY_GRID: Grid = Array(9).fill(null).map(() => Array(9).fill(null));

export default function App() {
  const [grid, setGrid] = useState<Grid>(EXAMPLE_PUZZLE);
  const [solution, setSolution] = useState<Grid | null>(null);
  const [isSolving, setIsSolving] = useState<boolean>(false);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [explanation, setExplanation] = useState<string>('');
  const [error, setError] = useState<string>('');

  const initialGrid = useMemo(() => grid.map(row => row.map(cell => cell !== null)), [grid]);

  const handleCellChange = useCallback((row: number, col: number, value: string) => {
    if (solution) return; // Don't allow changes after solving

    const newGrid = grid.map(r => [...r]);
    if (value === '' || value === '0') {
      newGrid[row][col] = null;
    } else {
      const num = parseInt(value, 10);
      if (!isNaN(num) && num >= 1 && num <= 9) {
        newGrid[row][col] = num as CellValue;
      }
    }
    setGrid(newGrid);
  }, [grid, solution]);

  const handleSolve = useCallback(async () => {
    setIsSolving(true);
    setError('');
    setSolution(null);
    setExplanation('');

    await new Promise(res => setTimeout(res, 50)); // Allow UI to update

    const solvedGrid = solveSudoku(grid);
    setIsSolving(false);

    if (solvedGrid) {
      setSolution(solvedGrid);
      setIsGenerating(true);
      try {
        const expl = await getSolutionExplanation(grid, solvedGrid);
        setExplanation(expl);
      } catch (e) {
        setError('Failed to generate explanation.');
        setExplanation('An error occurred while contacting the AI model.');
      } finally {
        setIsGenerating(false);
      }
    } else {
      setError('This puzzle is unsolvable. Please check the numbers.');
    }
  }, [grid]);

  const handleClear = useCallback(() => {
    setGrid(EMPTY_GRID);
    setSolution(null);
    setError('');
    setExplanation('');
  }, []);

  const handleReset = useCallback(() => {
    setGrid(EXAMPLE_PUZZLE);
    setSolution(null);
    setError('');
    setExplanation('');
  }, []);

  return (
    <div className="min-h-screen w-full bg-slate-900 flex flex-col items-center justify-center p-4 selection:bg-sky-500 selection:text-white">
      <main className="w-full max-w-5xl mx-auto flex flex-col lg:flex-row gap-8 items-start">
        <div className="w-full lg:w-1/2 flex flex-col items-center gap-6">
          <header className="text-center">
            <div className="flex items-center justify-center gap-3">
              <BrainIcon className="w-10 h-10 text-sky-400" />
              <h1 className="text-4xl font-bold text-slate-100 tracking-tight">
                Gemini Sudoku Solver
              </h1>
            </div>
            <p className="text-slate-400 mt-2">Enter a puzzle, then click 'Solve' to see the magic.</p>
          </header>

          <div className="relative w-full max-w-md aspect-square">
             {isSolving && (
                <div className="absolute inset-0 bg-slate-800 bg-opacity-70 flex items-center justify-center rounded-xl z-20">
                    <div className="flex flex-col items-center gap-2">
                         <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-400"></div>
                         <p className="text-slate-300 font-medium">Solving...</p>
                    </div>
                </div>
            )}
            <SudokuGrid 
              grid={solution || grid} 
              onCellChange={handleCellChange}
              isSolved={!!solution}
              initialGrid={initialGrid}
            />
          </div>
          
          {error && <p className="text-red-400 text-center font-semibold">{error}</p>}
          
          <Controls 
            isSolving={isSolving || isGenerating} 
            isSolved={!!solution}
            onSolve={handleSolve} 
            onClear={handleClear}
            onReset={handleReset}
          />
        </div>

        <div className="w-full lg:w-1/2 lg:mt-24">
           <div className="bg-slate-800/50 rounded-xl p-6 h-[60vh] lg:h-auto lg:max-h-[calc(100vh-10rem)] overflow-y-auto ring-1 ring-slate-700">
            <h2 className="text-2xl font-bold text-slate-100 flex items-center gap-2">
              <SparklesIcon className="w-6 h-6 text-sky-400" />
              AI Explanation
            </h2>
            <div className="mt-4 text-slate-300 prose prose-invert prose-p:text-slate-300 prose-strong:text-slate-100">
              {isGenerating ? (
                 <div className="flex items-center gap-3 text-slate-400">
                    <div className="animate-pulse bg-sky-400/20 h-3 w-3 rounded-full"></div>
                    <span>Gemini is thinking...</span>
                 </div>
              ) : explanation ? (
                <div className="whitespace-pre-wrap font-sans" dangerouslySetInnerHTML={{ __html: explanation.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br />') }} />
              ) : (
                <p className="text-slate-400 italic">The step-by-step solution explanation from Gemini will appear here once the puzzle is solved.</p>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
